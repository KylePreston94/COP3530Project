//Kyle Preston
//COP3530 Spring 2022
//Project part 1
#pragma once
#include <iostream>
#include <limits.h>
#include "d_except.h"
#include <list>
#include <fstream>
#include "d_matrix.h"
#include <queue>
#include <vector>
#include "graph.h"
#include "map.h"
#include <string>


using namespace std;


int main() {
	ifstream readFile;
	string fileName;
	string input;
	readFile.open("map1.txt");
	Map islandMap(readFile);
	
	graph g;
	stack<int> moves;
	queue<int> move;
	
//make the graph from the map1 textfile
	islandMap.mapToGraph(g);
	moves.push(0);
	g.clearVisit();

	::cout << "Recursive path \n";
	islandMap.findPathRecursive(g, moves);
	g.clearVisit();
	::cout << "Non recursive\n";
	islandMap.findPathNonRecursive1(g,moves);
	g.clearVisit();
	::cout << "Non Recursive 2\n";
	islandMap.findPathNonRecursive2(g,move);
	
	readFile.close();
	//Open map 2
	readFile.open("map2.txt");
	Map islandMap2(readFile);
	//Graph map 2
	islandMap2.mapToGraph(g);
	moves = stack<int>();
	moves.push(0);
	g.clearVisit();

	::cout << "Recursive path \n";
	islandMap2.findPathRecursive(g, moves);
	g.clearVisit();
	//::cout << "Non recursive\n";
	// Failed to run
	//islandMap2.findPathNonRecursive1(g, moves);
	g.clearVisit();
	//::cout << "Non Recursive 2\n";
	// Failed to run
	//islandMap2.findPathNonRecursive2(g, move);

	readFile.close();

	readFile.open("map3.txt");
	Map islandMap3(readFile);
	islandMap3.mapToGraph(g);
	moves = stack<int>();
	moves.push(0);
	g.clearVisit();
	islandMap3.findPathRecursive(g, moves);
	//failed to run
	//islandMap3.findPathNonrecursive1(g,moves);
	//g.clearVisit();
	//failed to run
	//islandMap3.findPathNonrecursive2(g,move);
	
	readFile.close();
}